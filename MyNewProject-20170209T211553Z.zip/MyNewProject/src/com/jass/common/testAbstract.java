package com.jass.common;

public abstract class testAbstract {
	
	abstract void draw();
	abstract void getName();

}
